<#
.SYNOPSIS
  Installs what LitArbi for Windows needs on a PC — Microsoft's .NET 8 Desktop Runtime — and, optionally, LitArbi itself
  from its MSI. Meant as a Group Policy computer startup script, or for Intune / Configuration Manager; runs as SYSTEM or
  an administrator, silently, and does nothing when everything is in place.

.PARAMETER Architecture
  x64 or arm64. Default: this PC's architecture. On ARM64 PCs "arm64" runs LitArbi natively (use the arm64 MSI);
  "x64" runs the x64 MSI under Windows' emulation.

.PARAMETER RuntimeInstaller
  A copy of windowsdesktop-runtime-8.x-win-<arch>.exe on a share (recommended for firms without internet access on the
  PCs). Without it, the current .NET 8 Desktop Runtime is downloaded from Microsoft (aka.ms/dotnet/8.0/...).

.PARAMETER Msi
  Optional: the LitArbi MSI to install or upgrade afterwards (e.g. \\server\software\LitArbi\LitArbi-<version>-x64.msi).

.EXAMPLE
  powershell.exe -ExecutionPolicy Bypass -File \\server\netlogon\Install-LitArbiPrerequisites.ps1 -Msi \\server\software\LitArbi\LitArbi-x64.msi
#>
param(
    [ValidateSet('x64', 'arm64')] [string] $Architecture = $(if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }),
    [string] $RuntimeInstaller,
    [string] $Msi,
    [string] $LogFile = (Join-Path $env:ProgramData 'LitArbi\deployment.log')
)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force -Path (Split-Path $LogFile) | Out-Null
function Log($text) { "$(Get-Date -Format s)  $text" | Add-Content -Path $LogFile; Write-Host $text }

# Where the runtime of this architecture lives: on ARM64 Windows the native runtime is in Program Files\dotnet and the
# x64 one in Program Files\dotnet\x64; on x64 Windows, Program Files\dotnet.
$dotnet = Join-Path $env:ProgramFiles 'dotnet'
if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -and $Architecture -eq 'x64') { $dotnet = Join-Path $dotnet 'x64' }
$present = Get-ChildItem (Join-Path $dotnet 'shared\Microsoft.WindowsDesktop.App') -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like '8.*' }

if ($present) {
    Log ".NET 8 Desktop Runtime ($Architecture) present: $($present.Name -join ', ')"
} else {
    $exe = $RuntimeInstaller
    if (-not $exe) {
        $exe = Join-Path $env:TEMP "windowsdesktop-runtime-8-win-$Architecture.exe"
        Log "Downloading the .NET 8 Desktop Runtime ($Architecture) from Microsoft"
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest "https://aka.ms/dotnet/8.0/windowsdesktop-runtime-win-$Architecture.exe" -OutFile $exe -UseBasicParsing
    }
    $sig = Get-AuthenticodeSignature $exe
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation') {
        throw "The runtime installer $exe is not signed by Microsoft — not installed."
    }
    Log "Installing the .NET 8 Desktop Runtime ($Architecture)"
    $p = Start-Process $exe -ArgumentList '/install', '/quiet', '/norestart' -Wait -PassThru
    if ($p.ExitCode -notin 0, 3010) { throw "The .NET 8 Desktop Runtime installer ended with code $($p.ExitCode)" }
    Log "Runtime installed (exit code $($p.ExitCode))"
}

if ($Msi) {
    Log "Installing $Msi"
    $p = Start-Process msiexec.exe -ArgumentList '/i', "`"$Msi`"", '/qn', '/norestart', '/l*v', "`"$(Join-Path (Split-Path $LogFile) 'msi.log')`"" -Wait -PassThru
    if ($p.ExitCode -notin 0, 1641, 3010) { throw "msiexec ended with code $($p.ExitCode) — see msi.log" }
    Log "LitArbi installed (exit code $($p.ExitCode))"
}
