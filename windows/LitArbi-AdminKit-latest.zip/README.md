# LitArbi for Windows: deployment guide for IT administrators

This guide covers rolling out LitArbi to a firm's PCs with Active Directory Group Policy, Microsoft Intune or
Configuration Manager: installation, updates and licences. It applies to LitArbi for Windows build 55 (0.9.53) and later.

## What is in the admin kit

| File | Use |
|---|---|
| `LitArbi-<version>-x64.msi` | Per-machine installation for x64 PCs (download next to the kit) |
| `LitArbi-<version>-arm64.msi` | Per-machine installation for ARM64 PCs (native) |
| `PolicyDefinitions\LitArbi.admx` + `en-US\`, `de-DE\` | Group Policy templates |
| `Install-LitArbiPrerequisites.ps1` | Installs the .NET 8 Desktop Runtime (and optionally the MSI), silently |
| `README.md` | This guide |

## 1. Choose how to install

**Per machine (recommended for firms):** the MSI installs LitArbi into `C:\Program Files\LitArbi` for every user of
the PC. People cannot change or update the program; your IT department decides the version.

**Per user:** `LitArbiSetup-<version>.exe` installs LitArbi into the user's profile without administrator rights, and
LitArbi updates itself. For single lawyers and small offices. Silent: `LitArbiSetup-<version>.exe /VERYSILENT
/SUPPRESSMSGBOXES /NORESTART` (e.g. from a logon script).

The two do not mix. Once the MSI is installed on a PC, the per-user setup refuses to install another copy. At its
first start, the per-machine LitArbi removes a per-user copy installed earlier. Only the program is removed; matters,
settings and the licence stay.

## 2. Prerequisite: the .NET 8 Desktop Runtime

LitArbi needs Microsoft's **.NET 8 Desktop Runtime** of the PC's architecture. `Install-LitArbiPrerequisites.ps1`
checks for it and installs it silently. By default it downloads the runtime from Microsoft; with
`-RuntimeInstaller \\server\share\windowsdesktop-runtime-8.x.x-win-x64.exe` it uses a copy from your file server
instead. It only runs installers signed by Microsoft. Microsoft Update keeps the runtime patched.

On ARM64 PCs, use the **arm64** MSI with the ARM64 runtime (native). The x64 MSI also runs there, under Windows'
emulation, with the x64 runtime.

## 3. Install with Group Policy

1. Copy the MSI (and the runtime installer, if you keep one) to a share that the PCs' computer accounts can read,
   e.g. `\\server\software\LitArbi\`.
2. **Runtime:** add `Install-LitArbiPrerequisites.ps1` as a computer **startup script** (Computer Configuration ▸
   Policies ▸ Windows Settings ▸ Scripts ▸ Startup), with parameters such as
   `-RuntimeInstaller \\server\software\LitArbi\windowsdesktop-runtime-8-win-x64.exe`.
   The script can also install LitArbi itself: add `-Msi \\server\software\LitArbi\LitArbi-<version>-x64.msi`.
   You can then skip step 3.
3. **LitArbi:** Computer Configuration ▸ Policies ▸ Software Settings ▸ Software installation ▸ New ▸ Package →
   the MSI, **Assigned**. PCs install it at their next restart.
4. **Updates:** add the new MSI to the same GPO and, on its *Upgrades* tab, mark it as upgrading the previous
   package. Or replace the `-Msi` path in the startup script. Every version replaces the previous one in place.

Intune: upload the MSI as a *Line-of-business app* (or wrap the script with the Win32 content prep tool). Assign the
runtime script as a *Platform script*, or package the runtime installer as a Win32 app with the command line
`/install /quiet /norestart`. Configuration Manager: an application with the MSI deployment type and a dependency on
the runtime.

Silent MSI command line: `msiexec /i LitArbi-<version>-x64.msi /qn /norestart`. To uninstall:
`msiexec /x LitArbi-<version>-x64.msi /qn`.

## 4. Group Policy settings

Copy `LitArbi.admx` and the language folders into the central store
(`\\<domain>\SYSVOL\<domain>\Policies\PolicyDefinitions`). The settings appear under *Administrative Templates ▸
LitArbi*, both in Computer and in User Configuration. When both are set, the computer setting wins. All values live in
`SOFTWARE\Policies\LitArbi`, so any tool that writes the registry (Intune OMA-URI / ADMX ingestion, scripts) works too.

| Setting | Value | What it does |
|---|---|---|
| **Updates** (`UpdateMode`) | 0 Automatic · 1 Notify only · 2 Off | Notify only (the default for the MSI): LitArbi reports a new version and its notes; you install it. Automatic: per-user installs update themselves, and per-machine installs ask for administrator rights to run the new MSI. Off: no update checks. |
| **Volume licence key** (`LicenseKey`, `LicenseEmail`) | `LITARBI-…` | Each PC activates itself with this key at its next start. See section 5. |
| **Lock the organisation's licence** (`LockLicense`) | 1 | People cannot deactivate the organisation's licence or enter another key; the key is shown shortened. |
| **Firm's LitArbi Server** (`ServerUrl`) | `https://litarbi.yourfirm.com` | Pre-fills the server address for signing in; enables "Get a licence from my firm's LitArbi Server". |

## 5. Licences for many PCs

An **enterprise key** is a single LitArbi licence key with as many activations as you ordered (for example 25).
Each PC that uses LitArbi takes one activation, and deactivating a PC frees it. There are two ways to get the key
onto the PCs. Neither needs anyone to type it.

### A. With the LitArbi Server (recommended)

When the firm runs a LitArbi Server (1.4 or later), its administrator enters the key once, and the key never
reaches the PCs' registry:

1. Browser → `https://litarbi.yourfirm.com` → **Administration ▸ LitArbi app licences**.
2. Paste the enterprise key, or several single keys, one per line, then choose **Add keys**. Each key is checked with
   LitArbi's licence service.
3. Choose who gets a licence (every user of the firm, or only the users you tick) and how many computers each person
   may use.

When a lawyer signs in to the firm's server in LitArbi (Settings ▸ LitArbi Server), a PC without a licence gets one
of the firm's. The licence window shows *Provided by: <firm> (LitArbi Server)*. At the gate, "Get a licence from my
firm's LitArbi Server…" does the same. The page lists every PC holding a seat, and **Release** frees one.

These events also free seats by themselves:

- switching a user off, or erasing them;
- the person choosing *Deactivate this PC…*;
- the person releasing a replaced laptop under *Your account* in the browser.

A released PC loses its licence at its next check (at most 12 hours while LitArbi runs), after the person finishes
their work. Guests invited from other firms never take a seat.

### B. With Group Policy

Set **Volume licence key** (and optionally **Lock the organisation's licence**). Each PC activates at its next LitArbi
start. Anyone who can read the policy on a PC can read the key. The number of activations limits the damage, and
LitArbi's licence service shows every activation. To move to a new key, change the policy; PCs switch at their next
start and release their old activation.

## 6. Data and profiles

- **Program:** `C:\Program Files\LitArbi` (per machine) or `%APPDATA%\LitArbi\App` (per user).
- **Settings:** `%APPDATA%\LitArbi` (roams with the profile).
- **Matters and the licence:** `%LOCALAPPDATA%\LitArbi` (stays on the PC). Backups go where Settings ▸ Backup says.
- **Word add-in:** each user's Word STARTUP folder, installed by LitArbi at its first start while Word is closed.
- **Logs** of the prerequisites script: `%ProgramData%\LitArbi\deployment.log` and `msi.log`.

LitArbi needs HTTPS access to `mgmt.litarbi.app` (licences), `raw.githubusercontent.com` (update information, unless
updates are Off) and your firm's LitArbi Server.
